package br.com.globlabs.exemplogradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
